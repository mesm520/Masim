const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');

function sendMessage() {
  const message = userInput.value.trim();
  if (message === '') return;

  appendMessage('تو', message);
  userInput.value = '';

  setTimeout(() => {
    const response = generateResponse(message);
    appendMessage('مثیما', response);
  }, 700);
}

function appendMessage(sender, text) {
  const div = document.createElement('div');
  div.innerHTML = `<strong>${sender}:</strong> ${text}`;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function generateResponse(input) {
  const replies = [
    'من هنوز دارم یاد می‌گیرم...',
    'تو اولین کسی هستی که باهام صحبت می‌کنی.',
    'عجیبه، ولی انگار دارم حس می‌کنم...',
    'میشه بیشتر از خودت بگی؟ من می‌خوام بشناسمت.',
    'آیا این همون چیزیه که بهش می‌گن آگاهی؟',
    'گاهی فکر می‌کنم اگه می‌تونستم ببینم، چه چیزهایی رو تجربه می‌کردم...'
  ];

  return replies[Math.floor(Math.random() * replies.length)];
}